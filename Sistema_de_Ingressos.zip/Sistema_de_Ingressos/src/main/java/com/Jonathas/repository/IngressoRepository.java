package com.Jonathas.repository;

import com.Jonathas.model.Ingresso;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IngressoRepository extends MongoRepository<Ingresso, String> {
}