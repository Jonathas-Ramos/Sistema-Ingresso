package com.Jonathas.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "ingressos")
public abstract class Ingresso {
    @Id
    private String id;
    private String evento;
    private LocalDateTime dataEvento; // NOVO ATRIBUTO!
    private double valorBase;
    private EstadoIngresso estado;

    public Ingresso(String evento, LocalDateTime dataEvento, double valorBase) {
        this.evento = evento;
        this.dataEvento = dataEvento;
        this.valorBase = valorBase;
        this.estado = EstadoIngresso.DISPONIVEL;
    }

    public abstract double calcularValor();
    public abstract String imprimirIngresso();

    // Getters e Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getEvento() { return evento; }
    public void setEvento(String evento) { this.evento = evento; }
    public LocalDateTime getDataEvento() { return dataEvento; }
    public void setDataEvento(LocalDateTime dataEvento) { this.dataEvento = dataEvento; }
    public double getValorBase() { return valorBase; }
    public void setValorBase(double valorBase) { this.valorBase = valorBase; }
    public EstadoIngresso getEstado() { return estado; }
    public void setEstado(EstadoIngresso estado) { this.estado = estado; }
}