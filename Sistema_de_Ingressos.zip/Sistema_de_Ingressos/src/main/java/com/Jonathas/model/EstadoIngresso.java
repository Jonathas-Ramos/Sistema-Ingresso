package com.Jonathas.model;

public enum EstadoIngresso {
    DISPONIVEL, RESERVADO, PAGO, EMITIDO, USADO, CANCELADO, DEVOLVIDO
}