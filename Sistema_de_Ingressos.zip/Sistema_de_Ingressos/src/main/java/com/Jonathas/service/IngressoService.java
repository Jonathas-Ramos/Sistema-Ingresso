package com.Jonathas.service;

import com.Jonathas.model.EstadoIngresso;
import com.Jonathas.model.Ingresso;
import com.Jonathas.model.PoliticaDevolucao;
import com.Jonathas.repository.IngressoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngressoService {

    @Autowired
    private IngressoRepository repository;

    public void salvarIngresso(Ingresso ingresso) {
        repository.save(ingresso);
    }

    public List<Ingresso> listarTodos() {
        return repository.findAll();
    }

    public Ingresso buscarPorId(String id) {
        return repository.findById(id).orElse(null);
    }

    // FLUXO B DO DIAGRAMA DE SEQUÊNCIA
    public Ingresso cancelar(String id) {
        Ingresso ingresso = buscarPorId(id);
        if (ingresso != null && ingresso.getEstado() != EstadoIngresso.CANCELADO) {
            ingresso.setEstado(EstadoIngresso.CANCELADO);
            return repository.save(ingresso);
        }
        return null;
    }

    // FLUXO C DO DIAGRAMA DE SEQUÊNCIA
    public Ingresso devolver(String id) {
        Ingresso ingresso = buscarPorId(id);
        if (ingresso != null && ingresso.getEstado() != EstadoIngresso.DEVOLVIDO && ingresso.getEstado() != EstadoIngresso.CANCELADO) {
            PoliticaDevolucao politica = new PoliticaDevolucao();

            if (politica.podeDevolver(ingresso)) {
                ingresso.setEstado(EstadoIngresso.DEVOLVIDO);
                double valorReembolso = politica.calcularReembolso(ingresso);

                // Simula o envio para o Gateway de Pagamento Externo
                System.out.println(">>> INTEGRAÇÃO GATEWAY: Reembolsando R$ " + valorReembolso + " para o ingresso " + id);

                return repository.save(ingresso);
            }
        }
        return null; // Não cumpriu a política (ex: muito perto do evento)
    }
}