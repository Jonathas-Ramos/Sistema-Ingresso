package com.Jonathas.service;

import com.Jonathas.model.EstadoUsuario;
import com.Jonathas.model.Usuario;
import com.Jonathas.repository.UsuarioRepository;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository repository;

    // Chave secreta para assinar o JWT (em produção isso fica em variáveis de ambiente)
    private final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    public String autenticar(String email, String senha) {
        Usuario usuario = repository.findByEmail(email);

        // Usuário não existe
        if (usuario == null) {
            throw new RuntimeException("Erro: Usuário não encontrado.");
        }

        // Verifica se está bloqueado (Diagrama 2.3)
        if (usuario.getEstado() == EstadoUsuario.BLOQUEADO) {
            throw new RuntimeException("Erro: Conta bloqueada devido a múltiplas tentativas falhas.");
        }

        // Validação de Senha (Diagrama 2.1 e 2.2)
        if (!usuario.getSenha().equals(senha)) {
            usuario.setTentativasFalhas(usuario.getTentativasFalhas() + 1);

            if (usuario.getTentativasFalhas() >= 3) {
                usuario.setEstado(EstadoUsuario.BLOQUEADO);
            }
            repository.save(usuario);
            throw new RuntimeException("Erro: Senha inválida.");
        }

        // Senha válida! Reseta falhas, muda estado e gera o Token (Diagrama 2.2, passo 8)
        usuario.setTentativasFalhas(0);
        usuario.setEstado(EstadoUsuario.LOGADO);
        repository.save(usuario);

        return gerarTokenJWT(usuario.getEmail());
    }

    private String gerarTokenJWT(String email) {
        return Jwts.builder()
                .setSubject(email)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3600000)) // Expira em 1 hora
                .signWith(key)
                .compact();
    }

    // Novo método para validar se o Token é autêntico e não está expirado
    public boolean isTokenValido(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false; // Token falso, expirado ou mal formatado
        }
    }


    // Este método FICA AQUI NO SERVICE!
    public void cadastrarUsuario(String email, String senha) {
        // Verifica se já existe alguém com esse e-mail
        if (repository.findByEmail(email) != null) {
            throw new RuntimeException("Erro: Este e-mail já está cadastrado no sistema.");
        }

        // Cria e salva o novo usuário
        Usuario novoUsuario = new Usuario(email, senha);
        repository.save(novoUsuario);
    }
}